#ifndef  __CONTROL_H
#define  __CONTROL_H
#include "sys.h"

void TIM2_Init(u16 arr,u16 pscl);

#endif 


