#ifndef __MOTOR_H
#define __MOTOR_H
#include "sys.h"

#define MOTORA	TIM3->CCR1
#define MOTORB	TIM3->CCR2
#define MOTORC	TIM3->CCR3
#define MOTORD	TIM3->CCR4

#define OPEN_lser  PAout(12)=1;
#define CLOSE_lser  PAout(12)=0;


void Motor_Init(void);

#endif


