#ifndef  __LED_H
#define  __LED_H
#include "sys.h"

#define  LED PAout(4)

void LED_Init(void);

#endif

